import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar';
import { Route, Switch } from 'react-router';
import Home from './components/Home';
import { ToastContainer } from 'react-toastify';
import AddContact from './components/AddContact';
import EditPage from './components/EditPage';

function App() {
  return (
    <div className="App">
     <Navbar />
     <ToastContainer />
     <Switch>
       <Route exact path="/">
         <Home />
       </Route>

       <Route path="/add">
         <AddContact />
       </Route>
       <Route exact path="/edit/:id" component={EditPage}/>
     </Switch>
    </div>
  );
}

export default App;
