import React, { useState, useRef } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import { useHistory } from 'react-router';
const AddContact = ({ contacts, addStudent }) => {
    const [name, setName] = useState();
    const [fatherName, setFatherName] = useState();
    const [dob, setDob] = useState();
    const [address, setAddress] = useState();
    const [city, setCity] = useState();
    const [state, setState] = useState();
    const [pin, setPin] = useState();
    const [phone, setPhone] = useState();
    const [email, setEmail] = useState();
    const [classOpted, setClassOpted] = useState();
    const [marks, setMarks] = useState();
    
    const reff = React.createRef();
    const history = useHistory();
    const monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"];
    const dateObj = new Date();
    const month = monthNames[dateObj.getMonth()];
    const day = String(dateObj.getDate()).padStart(2, '0');
    const year = dateObj.getFullYear();
    const currentDate = month +"," + '\n'+ day  + ',' + year;
    const [dateEnrolled, setDateEnrolled] = useState(currentDate);
    const submitHandler = (ed) => {
        console.log(reff.current.value);
        ed.preventDefault();
        // if (!name  || !email || !phone || !fatherName || !dob || !address || !city || !state || !pin || !classOpted || !marks || !dateEnrolled) {
        //     return toast.warning("Please fill all the fields !!");
        // }
        
        const checkPhoneExists = contacts.filter((contact) => (
            contact.phone == phone ? contact : null
        ));

        const checkEmailExists = contacts.filter((contact) => (
            contact.email == email ? contact : null
        ));


        if (checkPhoneExists.length > 0) {
            return toast.warning("phone No. is registered !!");
        }

        if (checkEmailExists.length > 0) {
            return toast.warning("Email is registered !!");
        }
        if(pin.length !== 6 ){
            return toast.warning("please enter correct pin");
        }
        if(phone.length !== 10){
            return toast.warning("please enter correct phone number");
        }
        var bday_in_milliseconds = new Date(dob);
        
       
        var now = new Date().getTime(); //current time in milliseconds
        console.log("current" + bday_in_milliseconds);
        console.log("now" + now);
        if (now - bday_in_milliseconds < 315569520000) { //315569520000 is 18 years in milliseconds
            return toast.warning("Date of birth can not be less than 10 years");
        }
       
        const data = {
            id: contacts.length > 0 ? contacts[contacts.length - 1].id + 1 : 0,
            name,
            fatherName,
            dob,
            address,
            city,
            state,
            pin,
            phone,
            email,
            classOpted,
            marks,
            dateEnrolled,
        }

        addStudent(data);
        history.push("/");


    }
    return (
        <div className="container">

            <form onSubmit={(edd) => { submitHandler(edd) }}>
                <div class="form-group">
                    <label for="name" style={{ "float": "left" }}><b>Name:</b></label>

                    <input type="text" class="form-control shadow" ref={reff} placeholder="Enter name" onChange={(e) => setName(e.target.value)} />
                </div><br></br>
                <div class="form-group">
                    <label for="age" style={{ "float": "left" }}><b>Father`s Name:</b></label>
                    <input type="text" class="form-control shadow" placeholder="Father name" onChange={(e) => setFatherName(e.target.value)} />
                </div>
                <br></br>
                <div class="form-group">
                    <label for="age" style={{ "float": "left" }}><b>DOB:</b></label>
                    <input type="date" class="form-control shadow" placeholder="" onChange={(e) => setDob(e.target.value)} />
                </div>
                <br></br>
                <div class="form-group">
                    <label for="age" style={{ "float": "left" }}><b>Address:</b></label>
                    <input type="text" class="form-control shadow" placeholder="Address" onChange={(e) => setAddress(e.target.value)} />
                </div>
                <br></br>
                <div class="form-group">
                    <label for="age" style={{ "float": "left" }}><b>City:</b></label>
                    <input type="text" class="form-control shadow" placeholder="City" onChange={(e) => setCity(e.target.value)} />
                </div>
                <br></br>
                <div class="form-group">
                    <label for="age" style={{ "float": "left" }}><b>State:</b></label>
                    <input type="text" class="form-control shadow" placeholder="State" onChange={(e) => setState(e.target.value)} />
                </div>
                <br></br>
                <div class="form-group">
                    <label for="age" style={{ "float": "left" }}><b>Pin:</b></label>
                    <input type="number" class="form-control shadow" placeholder="Pin" onChange={(e) => setPin(e.target.value)}  />
                </div>
                <br></br>
                <div class="form-group">
                    <label for="age" style={{ "float": "left" }}><b>Phone:</b></label>
                    <input type="number" class="form-control shadow" placeholder="Phone" onChange={(e) => setPhone(e.target.value)}   />
                </div>
                <br></br>


                <div class="form-group">
                    <label for="email" style={{ "float": "left" }}><b>Email:</b></label>
                    <input type="Email" class="form-control shadow" placeholder="Enter email" onChange={(e) => setEmail(e.target.value)} />
                </div>
                <br></br>
                <div class="form-group">
                    <label for="age" style={{ "float": "left" }}><b>Class Opted:</b></label>
                    <select  class="form-control shadow" placeholder="class opted" onChange={(e)=>{setClassOpted(e.target.value)}} >
                        <option value="">----select class----</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                    </select>
                </div>
                <br></br>
                <div class="form-group">
                    <label for="age" style={{ "float": "left" }}><b>Marks:</b></label>
                    <input type="number" class="form-control shadow" placeholder="marks" onChange={(e) => setMarks(e.target.value)} />
                </div>
                <br></br>
                <div class="form-group">
                    {/* <label for="age" style={{ "float": "left" }}><b>Date Enrolled:</b></label> */}
                    <input type="hidden" class="form-control shadow" placeholder="Date Enroll" value={()=>(setDateEnrolled(currentDate))} />
                </div>
                <br></br>
                <button type="submit" class="btn   btn-outline-info">Submit</button>&nbsp;
                <Link to="/" class="btn  btn-outline-primary"> Cancel</Link>
            </form>
        </div>
    );
}
const mapStateToProps = (state) => ({
    contacts: state,
});

const mapDispatchToProps = (dispatch) => ({

    addStudent: (data) => { dispatch({ type: "ADD_STUDENT", payload: data }) },

});

export default connect(mapStateToProps, mapDispatchToProps)(AddContact);
