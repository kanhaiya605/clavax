import React, { useState } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import { useHistory, useParams } from 'react-router';
const EditPage = ({ contacts, updateStudent }) => {
    const { id } = useParams();
    const currentContact = contacts.find((contact) => (
        contact.id === parseInt(id) ? contact : null
    ));
    const [name, setName] = useState(currentContact.name);
    const [fatherName, setFatherName] = useState(currentContact.fatherName);
    const [dob, setDob] = useState(currentContact.dob);
    const [address, setAddress] = useState(currentContact.address);
    const [city, setCity] = useState(currentContact.city);
    const [state, setState] = useState(currentContact.state);
    const [pin, setPin] = useState(currentContact.pin);
    const [phone, setPhone] = useState(currentContact.phone);
    const [email, setEmail] = useState(currentContact.email);
    const [classOpted, setClassOpted] = useState(currentContact.classOpted);
    const monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"];
    const dateObj = new Date();
    const month = monthNames[dateObj.getMonth()];
    const day = String(dateObj.getDate()).padStart(2, '0');
    const year = dateObj.getFullYear();
    
    const currentDate = month + "," + ' ' + day + ',' + year;
    const [dateEnrolled, setDateEnrolled] = useState(currentContact.dateEnrolled);
    const [marks, setMarks] = useState(currentContact.marks);
    const history = useHistory();
    const submitHandler = (e) => {
        e.preventDefault();
       

        const checkPhoneExists = contacts.filter((contact) => (
            (contact.phone == phone && (contact.id !== currentContact.id)) ? contact : null
        ));

        const checkEmailExists = contacts.filter((contact) => (
            (contact.email == email && contact.id !== currentContact.id) ? contact : null
        ));

        console.log(checkPhoneExists);
        if (checkPhoneExists.length > 0) {
            return toast.warning("phone No. is registered !!");
        }
        if(pin.length !== 6 ){
            return toast.warning("please enter correct pin");
        }
        if(phone.length !== 10){
            return toast.warning("please enter correct phone number");
        }

        if (checkEmailExists.length > 0) {
            return toast.warning("Email is registered !!");
        }

        const data = {
            id: currentContact.id,
            name,
            fatherName,
            dob,
            address,
            city,
            state,
            pin,
            phone,
            email,
            classOpted,
            marks,
            dateEnrolled
        }

        updateStudent(data);
        toast.success("updated successfully");
        history.push("/");


    }
    return (
        <div className="container">

            <form onSubmit={submitHandler}>
                <div class="form-group">
                    <label for="name" style={{ "float": "left" }}><b>Name:</b></label>

                    <input type="text" class="form-control shadow"  value={name} onChange={(e) => { return setName(e.target.value)}} />
                </div><br></br>
                <div class="form-group">
                    <label  style={{ "float": "left" }}><b>Father`s Name:</b></label>
                    <input type="text" class="form-control shadow" value={fatherName} onChange={(e) => setFatherName(e.target.value)} />
                </div>
                <br></br>
                <div class="form-group">
                    <label  style={{ "float": "left" }}><b>DOB:</b></label>
                    <input type="date" class="form-control shadow" value={dob} onChange={(e) => setDob(e.target.value)} />
                </div>
                <br></br>
                <div class="form-group">
                    <label  style={{ "float": "left" }}><b>Address:</b></label>
                    <input type="text" class="form-control shadow" value={address} onChange={(e) => setAddress(e.target.value)} />
                </div>
                <br></br>
                <div class="form-group">
                    <label  style={{ "float": "left" }}><b>City:</b></label>
                    <input type="text" class="form-control shadow" value={city} onChange={(e) => setCity(e.target.value)} />
                </div>
                <br></br>
                <div class="form-group">
                    <label  style={{ "float": "left" }}><b>State:</b></label>
                    <input type="text" class="form-control shadow" value={state} onChange={(e) => setState(e.target.value)} />
                </div>
                <br></br>
                <div class="form-group">
                    <label  style={{ "float": "left" }}><b>Pin:</b></label>
                    <input type="number" class="form-control shadow" value={pin} onChange={(e) => setPin(e.target.value)}  />
                </div>
                <br></br>
                <div class="form-group">
                    <label  style={{ "float": "left" }}><b>Phone:</b></label>
                    <input type="number" class="form-control shadow" value={phone} onChange={(e) => setPhone(e.target.value)}  />
                </div>
                <br></br>


                <div class="form-group">
                    <label for="email" style={{ "float": "left" }}><b>Email:</b></label>
                    <input type="Email" class="form-control shadow" value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>
                <br></br>
                <div class="form-group">
                    <label  style={{ "float": "left" }}><b>Class Opted:</b></label>
                    <select class="form-control shadow" onChange={(e)=>{setClassOpted(e.target.value)}} >
                        <option value={classOpted} >{classOpted}</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                    </select>
                </div>
                <br></br>
                <div class="form-group">
                    <label  style={{ "float": "left" }}><b>Marks:</b></label>
                    <input type="text" class="form-control shadow" value={marks} onChange={(e) => setMarks(e.target.value)} />
                </div>
                <br></br>
                <div class="form-group">
                    {/* <label  style={{ "float": "left" }}><b>Date Enrolled:</b></label> */}
                    <input type="hidden" class="form-control shadow" />
                </div>
                <br></br>
                <button type="submit" class="btn   btn-outline-info">Submit</button>&nbsp;
                <Link to="/" class="btn  btn-outline-primary"> Cancel</Link>
            </form>
        </div>
    );
}
const mapStateToProps = (state) => ({
    contacts: state,
});

const mapDispatchToProps = (dispatch) => ({

    updateStudent: (data) => { dispatch({ type: "EDIT_STUDENT", payload: data }) },

});

export default connect(mapStateToProps, mapDispatchToProps)(EditPage);
