import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import DataTable from 'react-data-table-component';

const Home = ({contacts , deleteStudent}) => {
    return (
        <div className="container">
     
            <Link to="/add" className="btn btn-primary">Add Student</Link>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>S.no</th>
                        <th>Student Name</th>
                        <th>Father`s Name</th>
                        <th>DOB</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Pin</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Class Opted</th>
                        <th>Marks(%)</th>
                        <th>Date Enrolled</th>
                        <th>Delete</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                   {  contacts.length > 0 ?
                   
                       contacts.map((contact , id)=>(
                           
                           <tr>
                               <td>{id+1}</td>
                              <td>{contact.name}</td>
                              <td>{contact.fatherName}</td>
                              <td>{contact.dob}</td>
                              <td>{contact.address}</td>
                              <td>{contact.city}</td>
                              <td>{contact.state}</td>
                              <td>{contact.pin}</td>
                              <td>{contact.phone}</td>
                              <td>{contact.email}</td>
                              <td>{contact.classOpted}</td>
                              <td>{contact.marks}</td>
                              <td>{contact.dateEnrolled}</td>
                               <td><button className="btn btn-danger" onClick={()=>(deleteStudent(contact.id))}><i className="fa fa-trash"></i></button></td>
                               <td><Link className="btn btn-success" to={`/edit/${contact.id}`}><i className="fa fa-pencil-square-o"></i></Link></td>
                           </tr>
                       )) :
                       <tr>
                           <td>No contact found</td>
                       </tr>
                   }
                    
                </tbody>
            </table>
        </div>
    );
}


const mapStateToProps = (state) =>({
    contacts:state,
});

const mapDispatchToProps = (dispatch) =>({

    deleteStudent:(id)=>{dispatch({ type: "DELETE_STUDENT" , payload:id })},

});

export default connect(mapStateToProps , mapDispatchToProps)(Home);