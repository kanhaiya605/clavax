import React from 'react';
import { Link } from 'react-router-dom';
const Navbar = () => {
    return (
        <div>
            
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
                <Link class="navbar-brand" to="/">&nbsp;&nbsp;Student</Link>
                
            </nav>
            <h1>Student Enrollment App</h1><br></br>
        </div>
    );
};

export default Navbar;
