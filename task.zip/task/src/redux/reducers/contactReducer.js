import React from 'react';

const initialState = [
    {
        id : 0,
        name: "kanhiaya mishra",
        fatherName: "bhajan mishra",
        dob:null,
        address: "Faridabad",
        city:"faridabad",
        state:"Haryana",
        pin:"121001",
        phone:"8800868647",
        email:"kanhaiya.aarya96@gmail.com",
        classOpted:"6",
        marks:"80",
        dateEnrolled:"November,30,2021",

     }
  
];
const ContactReducer = (state = initialState, actions) => {

    switch (actions.type) {
        case "DELETE_STUDENT":
            state = state.filter((contact) => (
                contact.id === actions.payload ? null : contact));
            return state;

        case "ADD_STUDENT":
            state = [...state, actions.payload]
            return state;
        case "EDIT_STUDENT":
            state = state.filter((contact) => (
                contact.id === actions.payload.id ? Object.assign(contact, actions.payload) : contact
            ));
            return state;
        default: return state;
    }


};

export default ContactReducer;